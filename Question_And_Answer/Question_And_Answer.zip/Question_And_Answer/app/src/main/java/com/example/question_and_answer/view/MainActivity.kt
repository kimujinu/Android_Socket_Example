package com.example.question_and_answer.view


import com.example.question_and_answer.R
import com.example.question_and_answer.base.ActivityBase
import com.example.question_and_answer.databinding.ActivityMainBinding
import com.example.question_and_answer.viewModel.MainViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel


class MainActivity : ActivityBase<ActivityMainBinding,MainViewModel>(){
    override val layoutResourceId: Int
        get() = R.layout.activity_main

    override val viewModel:MainViewModel by viewModel()

    override fun init() {
    }

    override fun initListener() {
    }

    override fun initDatabinding() {
    }

}

