package com.example.question_and_answer.viewModel

import com.example.question_and_answer.base.ViewModelBase

class FragMainViewModel : ViewModelBase() {
}